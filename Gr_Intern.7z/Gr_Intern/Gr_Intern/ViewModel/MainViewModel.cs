using GalaSoft.MvvmLight;
using Gr_Intern.AppService;
using System.Windows.Navigation;

namespace Gr_Intern.ViewModel
{
   
    public class MainViewModel : ViewModelBase
    {
        private readonly NetworkService networkService;
        private readonly INavigationServiceEx navigationService;
        private bool _isLogged = false;
        public MainViewModel(NetworkService networkService,NavigationService navigationService)
        {
            this.networkService = networkService;
            this.navigationService = navigationService;

            this.networkService.MessageEvent += NetworkService_MessageEvent;
        }

        public async void SendButtonClick()
        {
            await this.networkService.SendMessage(this.UserMessage);
            this.UserMessage = null;
        }

        internal void OnWindowsLoaded()
        {
            if (this.networkService.IsLogged == false)
            {
                this.navigationService.Navigate<MainViewModel>();
            }
        }

        private void NetworkService_MessageEvent(string message)
        {
            this.MainText += "\n" + message;
        }

        private async void RequestUserName()
        {
        }


        private string mainText;
        public string MainText
        {
            get => this.mainText;
            set => this.Set(ref this.mainText, value);
        }
        private string userMessage;
        public string UserMessage
        {
            get => this.userMessage;
            set => this.Set(ref this.userMessage, value);
        }
    }
}