using CommonServiceLocator;
using GalaSoft.MvvmLight.Ioc;
using Gr_Intern.AppService;
using InterClient.ViewModel;

namespace Gr_Intern.ViewModel
{

    public class ViewModelLocator
    {

        public ViewModelLocator()
        {
            SimpleIoc.Default.Register<NetworkService>(true);
            ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);
            SimpleIoc.Default.Register<AuthViewModel>();



            SimpleIoc.Default.Register<MainViewModel>();
            this.Register<ShellViewModel, MainWindow>();
            this.Register<MainViewModel, ChatPage>();
            this.Register<AuthViewModel, Auth>();
        }
        public MainViewModel MainViewModel => ServiceLocator.Current.GetInstance<MainViewModel>();
        public NavigationServiceEx NavigationService => ServiceLocator.Current.GetInstance<NavigationServiceEx>();
        public AuthViewModel AuthViewModel => ServiceLocator.Current.GetInstance<AuthViewModel>();
        public ShellViewModel ShellViewModel => ServiceLocator.Current.GetInstance<ShellViewModel>();

        public MainViewModel Main
        {
            get
            {
                return ServiceLocator.Current.GetInstance<MainViewModel>();
            }
        }


        public AuthViewModel Auth
        {
            get
            {
                return ServiceLocator.Current.GetInstance<AuthViewModel>();
            }
        }
           
        public static void Cleanup()
        {
            // TODO Clear the ViewModels
        }

        public void Register<VM, V>()
           where VM : class
           where V : class
        {
            SimpleIoc.Default.Register<VM>();
            SimpleIoc.Default.Register<V>();

            this.NavigationService.Configure(typeof(VM).FullName, typeof(V));
        }
    }
}