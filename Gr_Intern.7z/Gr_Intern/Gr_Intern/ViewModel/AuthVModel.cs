﻿using GalaSoft.MvvmLight;
using Gr_Intern.AppService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Navigation;

namespace Gr_Intern.ViewModel
{
    public class AuthViewModel : ViewModelBase
    {
        private readonly NetworkService networkService;
        private readonly NavigationServiceEx navigationService;
        public AuthViewModel(NetworkService networkService, INavigationServiceEx navigationService)
        {
            this.networkService = networkService;
            this.navigationService = navigationService;
        }

        private string login;
        public string UserLogin
        {
            get => this.login;
            set =>this.Set(ref this.login, value);
        }

        public async Task<bool> Auth()
        {
            bool authstate = false;
            await this.networkService.SetLogin(this.UserLogin);
            this.navigationService.Navigate<MainViewModel>();
            return authstate;
            
        }
    }
}
