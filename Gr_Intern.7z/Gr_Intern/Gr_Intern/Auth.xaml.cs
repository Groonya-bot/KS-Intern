﻿using Gr_Intern.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Gr_Intern
{
    
    public partial class Auth : Window
    {
        private AuthViewModel ViewModel => this.DataContext as AuthViewModel;
        public Auth()
        {
            InitializeComponent();
        }


private async void AuthButtonClick(object sender, RoutedEventArgs e)
        {
            await this.ViewModel.Auth();

        }
    }




}
