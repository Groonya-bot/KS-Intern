﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkLibrary.Common
{
    public class CommonData
    {
        public static string LoginMessage = "$l";
    }
}
